package assignment1;

public class Main {

    /*public static void main(String[] args) {
        //new Test("takeAction() benefits from improvement", "An improved tile provides a 5% attack bonus.", () -> {
        //new Test("takeAction() expends worker at 10 jobs", () -> {
            Worker worker = new Worker(new Tile(0, 0), 10.0, "Emus");

            worker.numberOfJobs = 9;
            worker.takeAction(worker.getPosition());

            // The worker should be removed.
            Test.assertBool(!worker.getPosition().removeUnit(worker));
        }),

                    //9.5);
    }

     */
}
