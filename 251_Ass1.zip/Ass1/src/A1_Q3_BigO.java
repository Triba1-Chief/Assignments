import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.Line2D;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.*;

    public class A1_Q3_BigO {

        private static ChartComponent chart;

        public static void main(String[] args) throws IOException {
            List<String> wordList = Files.readAllLines(Paths.get("words.txt"));
            ArrayList<DataPoint> data = new ArrayList<>();
            SwingUtilities.invokeLater(() -> {
                JFrame frame = new JFrame("Time Complexity Chart");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.add(chart = new ChartComponent(data));
                frame.pack();
                frame.setVisible(true);
            });
            int TOTAL = 0;
            double k = 2;
            for (int m = 100; m <= wordList.size(); m *= k) for (int u = 100; u <= 10000; u *= k) TOTAL++;
            int prog = 0;
            for (int m = 100; m <= wordList.size(); m *= k) {
                for (int u = 100; u <= 10000; u *= k) {
                    String[] posts = generateTestCase(m / 2, u, m, wordList);
                    long startTime = System.nanoTime();
                    A1_Q3.Discussion_Board(posts);
                    double et = (System.nanoTime() - startTime) / 1e6;
                    data.add(new DataPoint(u * m, et));
                    data.sort(Comparator.comparingInt(a -> a.x));
                    if (chart != null) SwingUtilities.invokeLater(chart::repaint);
                    System.out.printf("U=%d, M=%d, TotalWords=%d, Time=%.2f ms :: %.2f%%%n", u, m, u * m, et, 100.0 * ++prog / TOTAL);
                }
            }
        }

        public static String[] generateTestCase(int C, int U, int M, List<String> wordList) {
            List<String> commonWords = wordList.subList(0, C);
            List<String> nonCommonWords = wordList.subList(C, wordList.size());

            List<String> posts = new ArrayList<>();
            Random rand = new Random();

            for (int i = 0; i < U; i++) {
                String username = "User" + (i + 1);
                ArrayList<String> words = new ArrayList<>(commonWords);

                for (int j = 0; j < M - C; j++) {
                    words.add(nonCommonWords.get(rand.nextInt(nonCommonWords.size())));
                }

                Collections.shuffle(words);
                String post = username + " " + String.join(" ", words);
                posts.add(post);
            }

            return posts.toArray(new String[0]);
        }

        static class DataPoint {
            int x;
            double y;

            DataPoint(int x, double y) {
                this.x = x;
                this.y = y;
            }
        }

        static class ChartComponent extends JComponent {
            private static final int PAD = 50;
            private final ArrayList<DataPoint> dataPoints;
            private boolean logScale = false;

            ChartComponent(ArrayList<DataPoint> dataPoints) {
                this.dataPoints = dataPoints;
                setPreferredSize(new Dimension(800, 600));
                setFocusable(true);
                addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyPressed(KeyEvent e) {
                        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                            System.exit(0);
                        } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                            logScale = !logScale;
                            repaint();
                        }
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (dataPoints.isEmpty()) return;
                Graphics2D g2 = (Graphics2D) g;

                int width = getWidth();
                int height = getHeight();

                double maxX = dataPoints.stream().mapToDouble(dp -> logScale ? Math.log(dp.x) : dp.x).max().orElse(1.0);
                double maxY = dataPoints.stream().mapToDouble(dp -> logScale ? Math.log(dp.y) : dp.y).max().orElse(1.0);
                double minX = dataPoints.stream().mapToDouble(dp -> logScale ? Math.log(dp.x) : dp.x).min().orElse(1.0);
                double minY = dataPoints.stream().mapToDouble(dp -> logScale ? Math.log(dp.y) : dp.y).min().orElse(1.0);

                g2.drawLine(PAD, height - PAD, width - PAD, height - PAD); // X-axis
                g2.drawLine(PAD, PAD, PAD, height - PAD); // Y-axis

                g2.drawString("Total Words" + (logScale ? " (log)" : ""), width / 2, height - 10);
                g2.drawString("Time (ms)" + (logScale ? " (log)" : ""), 10, height / 2);

                // draw min/max labels
                g2.drawString(String.format("%.2f", logScale ? Math.exp(minX) : minX), PAD, height - PAD + 15);
                g2.drawString(String.format("%.2f", logScale ? Math.exp(maxX) : maxX), width - PAD - 20, height - PAD + 15);
                g2.drawString(String.format("%.2f", logScale ? Math.exp(minY) : minY), PAD - 40, height - PAD);
                g2.drawString(String.format("%.2f", logScale ? Math.exp(maxY) : maxY), PAD - 40, PAD + 15);


                g2.setColor(Color.BLUE);
                for (DataPoint dp : dataPoints) {
                    int x = map(dp.x, minX, maxX, PAD, width - PAD);
                    int y = map(dp.y, minY, maxY, height - PAD, PAD);
                    g2.fillOval(x - 3, y - 3, 6, 6);
                }

                g2.setColor(Color.RED);
                for (int i = 1; i < dataPoints.size(); i++) {
                    DataPoint prev = dataPoints.get(i - 1);
                    DataPoint curr = dataPoints.get(i);
                    int x1 = map(prev.x, minX, maxX, PAD, width - PAD);
                    int y1 = map(prev.y, minY, maxY, height - PAD, PAD);
                    int x2 = map(curr.x, minX, maxX, PAD, width - PAD);
                    int y2 = map(curr.y, minY, maxY, height - PAD, PAD);
                    g2.draw(new Line2D.Double(x1, y1, x2, y2));
                }
            }

            private int map(double value, double fromLow, double fromHigh, int toLow, int toHigh) {
                if (logScale) value = Math.log(value);
                return (int) ((value - fromLow) * (toHigh - toLow) / (fromHigh - fromLow) + toLow);
            }
        }
    }

