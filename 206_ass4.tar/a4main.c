#include "a4phonebook.c"



int menu(void) {
        int menuInput;

        //Reading user input for menu options
        printf("Phonebook Menu: (1)Add, (2)Find, (3)List, (4)Quit > ");
        scanf("%i", &menuInput);
        getchar();//Removes newline character from buffer

        return menuInput;
}



int main(void) {
        loadCSV("newphonebook.csv");

        int errorCode;

        int result = menu();

        while (result != 4) {
                if (result == 1) {//Adding records
                        char name[50];
                        char birth[12];
                        char phone[15];

                        printf("Name: ");
                        fgets(name,50, stdin);
                        name[strcspn(name, "\n")] = '\0';//Removing the newline character from name

                        printf("Birth date: ");
                        fgets(birth,12,stdin);
                        birth[strcspn(birth, "\n")] = '\0';//Removing the newline character from birth

                        printf("Phone: ");
                        fgets(phone,15,stdin);
                        phone[strcspn(phone, "\n")] = '\0';//Removing the newline character from phone

                        errorCode = addRecord(name,birth,phone);

                        if (errorCode == 1) {
                                printf("The phonebook is full\n");
				 }
                        else if (errorCode != 0) {//In cases where the input is greater than array size or any other error
                                printf("Your data was unsuccessfully processed as it is may be too large to process.\n");
                        }
                }
                else if (result == 2) {//Searching records
                        char input[50];

                        printf("Find name: ");
                        fgets(input, 50 ,stdin);
                        input[strcspn(input, "\n")] = '\0';//Removing the newline character from name

                        findRecord(input);
                }
                else if (result == 3) {//Lists the records
                        errorCode = listRecords();

                        if (errorCode != 0) {
                                printf("The phonebook is empty\n");
                        }
                }
                else {//Invalid entry
                        printf("Invalid menu selection\n");
                }

                result = menu();
        }

        saveCSV("newphonebook.csv");
        printf("End of phonebook program\n");

        return 0;
}

