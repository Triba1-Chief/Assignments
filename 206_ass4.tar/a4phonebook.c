#include <stdio.h>
#include <stdlib.h>
#include <string.h>



//Phone record structure
struct PHONE_RECORD {
	char name[50];
	char birthdate[12];
	char phone[15];
};



//Phonebook array
struct PHONE_RECORD phonebook[10]; //contains phone records
int phonebook_length = 0; //keeps track of no of items the phonebook contains



//Adding a phone record to the array
int addRecord(char name[], char birth[], char phone[]) {
	if (phonebook_length < 10) {
		strcpy(phonebook[phonebook_length].name, name);
		strcpy(phonebook[phonebook_length].birthdate, birth);
		strcpy(phonebook[phonebook_length].phone, phone);

		phonebook_length++;
		return 0;
	}
	else {
		return 1;
	}
}



//Listing all the phone records in the phonebook
int listRecords(void) {
	if (phonebook_length == 0) {
                return 1;
        }
	
	printf("---- NAME ---- ---- BIRTH DATE ---- ---- PHONE ----\n");
	
	for (int i = 0; i < phonebook_length; i++) {
		printf("%-14s ",phonebook[i].name);
		printf("%-20s ",phonebook[i].birthdate);
		printf("%-10s\n",phonebook[i].phone);
	}

	return 0;
}



//Finding a phone record in the phonebook
int findRecord(char name[]) {
	for (int i = 0; i < phonebook_length; i++) {
		if (strcmp(phonebook[i].name,name) == 0) {
			printf("---- NAME ---- ---- BIRTH DATE ---- ---- PHONE ----\n");
                	printf("%-14s ",phonebook[i].name);
                	printf("%-20s ",phonebook[i].birthdate);
                	printf("%-10s\n",phonebook[i].phone);
			return i;
        	}
	}
		
	printf("Phone record not found\n");
	return -1;
}



//Filling the array from a CSV file
int loadCSV(char *filename) {
	phonebook_length = 0; //test this

	FILE *csvFile = fopen(filename,"rt");


	if (csvFile == NULL) {//File doesn't exist
		return 1;
	}


	char csvData[100000]; //holds all data on a line as an array
	int tempCounter = 0; //ensures the null terminator is added the right index
	int charCounter = 0; //counter for indexing characters on a line
	char name[50]; //all three taken directly from struct phonebook
        char birth[12];
        char phone[15];


	fgets(csvData,99999,csvFile); // Reading the first line
	if (fgets(csvData,99999,csvFile) == NULL) { //If the file is empty or only has the header
		fclose(csvFile);
		return 1;
	}

	
	while (!feof(csvFile)) {
		charCounter = 0;

		for (int i = 0; csvData[charCounter] != '\0' && i < 50 && csvData[charCounter] != ','; charCounter++, i++) {
                	name[i] = csvData[charCounter];
			tempCounter = i;
        	}
		name[tempCounter + 1] = '\0';//Inserts the end of the word at the correct index
                charCounter++;//Moves the index away from the comma

        	for (int i = 0; csvData[charCounter] != '\0' && i < 12 && csvData[charCounter]!= ','; charCounter++, i++) {
                	birth[i] = csvData[charCounter];
			tempCounter = i;
        	}
                birth[tempCounter + 1] = '\0';//Inserts the end of the word at the correct index
                charCounter++;//Moves the index away from the comma

        	for (int i = 0; csvData[charCounter] != '\0' && i < 15 && csvData[charCounter]!= ','; charCounter++, i++) {
                	phone[i] = csvData[charCounter];
			tempCounter = i;
        	}
                phone[tempCounter + 1] = '\0';//Inserts the end of the word at the correct index
	
		addRecord(name, birth, phone);

		fgets(csvData,99999,csvFile);
	}

	fclose(csvFile);
}



//Saving the array to a CSV file
int saveCSV(char *filename) {
	FILE *csvFile = fopen(filename,"wt");//Overwrites if it exits

	if (csvFile == NULL) {//File doesn't exist
		return 1;
	}
	
	if (phonebook_length != 0) {
		fprintf(csvFile, "name,birthdate,phone\n");

		for (int i = 0; i < phonebook_length; i++) {
			fprintf(csvFile, "%s,%s,%s\n", phonebook[i].name, phonebook[i].birthdate, phonebook[i].phone);
                }
                
		fclose(csvFile);
                return 0;
        }
        else {
		fclose(csvFile);
                return 2;
        }
}
