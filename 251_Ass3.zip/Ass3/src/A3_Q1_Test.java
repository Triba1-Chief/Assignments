import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.IntStream;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class A3_Q1_Test {
    static String[][][] boards = {
            {

                    {"X", "A", "X"},
                    {"X", " ", "X" },
                    {"X", "X", "X"}
            },
            {
                    {"N", "A", "Q", "X", "X"},
                    {"N", " ", "X", ".", "X"},
                    {"N", "X", "X", "X", "X"}
            },
            {
                    {"X", "D", "R", "V", "X"},
                    {"X", ".", "X", ".", "X"},
                    {"X", "X", "X", "X", "X"}
            },
            {
                    { "X", "X", "X", "X", "X", "X", "X", "A", "X", "X", "X", "X", "X", "X", "X", "B", "X", "X", "X", "X"},
                    { "X", ".", ".", " ", ".", ".", "X", ".", "X", ".", ".", ".", ".", ".", ".", " ", ".", ".", ".", "X"},
                    { "X", ".", "X", "X", "X", ".", ".", ".", "X", ".", "X", ".", "X", "X", "X", "X", "X", "X", ".", "X"},
                    { "X", ".", "X", ".", "X", "X", "X", "X", "X", ".", "X", ".", "X", ".", ".", ".", ".", "X", ".", "X"},
                    { "X", ".", "X", ".", ".", ".", " ", ".", ".", ".", "X", ".", "X", ".", "X", "X", ".", "X", ".", "X"},
                    { "X", ".", "X", ".", "X", ".", "X", "X", "X", "X", "X", "X", "X", ".", "X", "X", ".", "X", ".", "X"},
                    { "X", ".", "X", ".", "X", ".", "X", ".", ".", ".", "X", ".", ".", ".", "X", ".", ".", ".", ".", "X"},
                    { "X", ".", "X", ".", "X", ".", "X", "X", "X", "X", "X", "X", "X", ".", "X", "X", "X", "X", ".", "X"},
                    { "X", ".", ".", ".", "X", ".", "X", " ", "X", ".", ".", " ", ".", ".", "X", ".", ".", "X", ".", "X"},
                    { "X", "X", "X", "X", "X", "X", "X", "D", "X", "X", "X", "X", "X", "X", "X", "X", "C", "X", "X", "X"}
            }

    };

    static int[] frogs = {0,0,2,2};

    static int[] leftovers = {0,1,0,3};

    @ParameterizedTest
    @MethodSource("testDataProvider")
    void testGame(String[][] board, int expectedFrogs, int expectedLeftovers) {
        int[] result = A3Q1.saving_frogs(board);
        assertAll(() -> assertEquals(expectedFrogs, result[0], "Incorrect number of frogs"),
                () -> assertEquals(expectedLeftovers, result[1], "Incorrect number of leftovers")
        );
    }

    static Stream<Arguments> testDataProvider() {
        return IntStream.range(0, boards.length).mapToObj(i -> Arguments.of(
                boards[i],
                frogs[i],
                leftovers[i]
        ));
    }

    @Test
    void testArraysConsistency() {
        assertAll(
                () -> assertTrue(boards.length > 0, "No test boards provided"),
                () -> assertEquals(boards.length, frogs.length,
                        "Boards and frogs arrays length mismatch"),
                () -> assertEquals(boards.length, leftovers.length,
                        "Boards and leftovers arrays length mismatch")
        );
    }
}
