#!/bin/bash

#Name: Samuel Kinyua
#ID NO: 261074364


#Creating input variables
source_directory=$1
target_directory=$2


#Checking if both directories have been provided as input.
if [[ -z $target_directory ]]
then
	echo 'Error: Expected two input parameters.'
	echo 'Usage: ./sortedcopy.sh <sourcedirectory> <targetdirectory>'
	exit 1
fi


#Checking if the first input is a directory
if ! [[ -d $source_directory ]]
then
		echo 'Error: Input parameter #1 $source_directory is not a directory.'
		echo 'Usage: ./sortedcopy.sh <sourcedirectory> <targetdirectory>'
		exit 2
fi


#Creating the target directory by first checking if it already exists.
if [[ -d $target_directory ]] 
then 
	echo "Directory $target_directory already exists. Overwrite? (y/n)"
	read answer

	if [[ $answer = 'y' ]]
	then
		rm -r $target_directory
	else
		exit 3
	fi

fi


#Creating the target directory (together with parent directories if non existant)
mkdir -p $target_directory


#Copying the files from source to target directory (Used if files exist inside the directory)
for file in $source_directory/* #Ensures we have the full file address 
do
	if [[ -f $file ]] #Ensures we only copy files
	then
		cp $file $target_directory
	else
		continue
	fi
done


#Appending numbers to the beginning of the file in the target directory
cd $target_directory

sorted_list=$(ls | sort -r)

i=1

for file in $sorted_list
do
	cp -r $file $i'.'$file
	rm -r $file
	i=$(( $i+1 ))
done

exit 0
