#!/bin/bash

#Q1.1
# Name: Samuel Kinyua
# ID No: 261074364

#Q1.2
pwd
ls *.txt

#Q1.3
mkdir backup
cd backup
echo 'Moved to backup directory'
pwd

#Q1.4
cp ../*.txt ../backup
echo 'Copied all text files to backup directory'

#Q1.5
echo 'Current backup:' >> date.txt
date >> date.txt
cat date.txt

#Q1.6
tar -zcvf txtarchive.tgz *.txt
echo "Created archive txtarchive.tgz"
ls -l
